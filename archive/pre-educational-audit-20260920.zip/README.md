# از Python تا ساخت Mini-GPT — ویرایش سوم

Deployment and environment cleanup instructions (English): [DEPLOYMENT.md](DEPLOYMENT.md).
From the full source checkout, run `python -B prepare_release.py` to validate and
package the static site without publishing. These deployment tools are not part
of the standalone Mini-GPT download.
The latest navigation, terminology, glossary and typography review is recorded
in [EDITORIAL_REVIEW.md](EDITORIAL_REVIEW.md) in the full source checkout.

کتاب فارسیِ چندصفحه‌ای برای همراهی چند هفته تا چند ماه: یادگیری، ساختن، خراب‌کردن، عیب‌یابی و بازگشت به مفهوم‌ها. برای خواننده‌ای با دانش Python و بدون پیش‌زمینهٔ هوش مصنوعی نوشته شده است.

## از اینجا آغاز کنید

**[بازکردن کتاب](dist/index.html)** — ۷۲ درس، ۳۵ فصل، ۱۰ بخش و ۱۰ ایستگاه عملی. پاسخ‌ها از درس جدا هستند. [راهنمای مسیر](dist/guide.html) روش کار، نصب و ثبت پیشرفت را توضیح می‌دهد.

[واژه‌نامهٔ متصل](dist/glossary.html) ۲۱۳ مفهوم دارد: نام‌های فنی مانند Tensor، Embedding و Attention انگلیسی می‌مانند و توضیح فارسی، مثال و ارتباط با پروژه دارند. از پیوند کم‌رنگ هر مفهوم می‌توانید به توضیح بروید و به همان جای درس برگردید. پایان هر درس، گام بعد و جای شما در مسیر روشن است. قلم Vazirmatn همراه کتاب قرار دارد؛ کد همچنان با قلم monospace نمایش داده می‌شود.

**[آزمایشگاه](dist/lab.html)**: نویسه و شناسه، softmax، توجه و پوشش، شکل تنسور، و بازرسِ عددهای واقعی checkpoint. **[دفتر آزمایش](dist/journal.html)**: پیش‌بینی، تنظیمات، مشاهده و تفسیر با ذخیرهٔ محلی و خروجی قابل انتقال. رابط، اطلس بازشدنی و ترکیب‌های متفاوتِ مطالعه، محاسبه، ساخت و عیب‌یابی دارد؛ سایدبار دائمی فضای متن را نمی‌گیرد.

نیازی به نصب یا اینترنت برای خواندن نیست؛ `index.html` ریشه نیز شما را به کتاب می‌برد. متن فارسی راست‌به‌چپ و کد/فرمول چپ‌به‌راست است. مسیر قبلی/بعدی، جست‌وجوی عنوان درس، مرحلهٔ پروژه و پیشرفت انتخابی همراه شماست. خروجی پیشرفت ویرایش دوم نیز وارد می‌شود. برای نگهداری دفتر و پیشرفت مرتب خروجی JSON بگیرید؛ دانلودِ مسدودشده، جایگزین متنی قابل کپی دارد.

روش پیشنهادی برای ذخیرهٔ مشترک و مطمئن‌تر بین صفحه‌ها، پیش‌نمایش فقط روی رایانهٔ خودتان است؛ رفتار ذخیره در `file://` به مرورگر بستگی دارد:

```sh
python -m http.server 8000 --bind 127.0.0.1 --directory dist
```

سپس `http://127.0.0.1:8000` را باز کنید. برای توقف Ctrl+C بزنید. فایل‌ها به هیچ سرویس بیرونی نیاز ندارند.

## پروژهٔ همراه

[راهنمای کامل Mini-GPT](mini_gpt/README.md) نصب، معماری، داده، تنظیمات، آموزش، ارزیابی، ذخیره/ادامه، تولید، بازرسی و رفع خطا را توضیح می‌دهد. [مرحله‌های ساخت](mini_gpt/stages/README.md) ۲۳ ایستگاه اجرایی را به قطعه‌های مشترک مدل وصل می‌کند؛ v0 تا v8 برای مقایسهٔ نسخه‌های قبلی محفوظ‌اند. [دفتر Markdown](mini_gpt/learning-log.md) نیز جایگزین غیرمرورگری دفتر است.

نسخهٔ صفر فقط Python می‌خواهد. نسخه‌های عصبی با PyTorch، کتابخانهٔ آرایه و مشتق خودکار، اجرا می‌شوند. این ویرایش روی Python 3.11 / PyTorch **2.14.0+cpu** آزموده شده؛ حداقل وابستگی۲.۶ است. نسخهٔ۲.۵.۱ که در سابقهٔ ویرایش دوم آمده، دیگر پیشنهاد نصب نیست. فقط checkpoint مورد اعتماد خودتان را بارگذاری کنید؛ `weights_only=True` مجوز اعتماد به فایل ناشناس نیست. GPU در این محیط آزموده نشده است.

```sh
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m mini_gpt.smoke_test
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

فرمان‌های بالا برای Windows هستند؛ در Linux/macOS از `.venv/bin/python` استفاده کنید. از مفسر همان محیط استفاده کنید تا بستهٔ نصب‌شده پیدا شود.

اگر خروجی فارسیِ هدایت‌شده به فایل/ترمینال خطای encoding داد، پس از نام مفسر گزینهٔ `-X utf8` بگذارید. این فقط کدگذاری خروجی را عوض می‌کند، نه مدل.

```sh
python -m mini_gpt.milestones --stage 6
python -m mini_gpt.train --text data/sample.txt --output runs/first --steps 100 --context-length 16 --embedding-dim 32 --num-heads 4 --num-layers 2 --batch-size 8 --schedule cosine --warmup-steps 10 --decay-steps 100 --device cpu
python -m mini_gpt.inspect --checkpoint runs/first/best.pt --prompt "مدل زبان" --output runs/first/inspection.json --metrics runs/first/metrics.csv --device cpu
```

فرمان دوم به پوشهٔ تازه نیاز دارد. JSON فرمان سوم را در آزمایشگاه وارد کنید؛ مرورگر PyTorch اجرا نمی‌کند و فایل `.pt` نمی‌خواند. نمونهٔ همراه کتاب واقعاً از آموزش۱۰۰گامی روی `data/sample.txt` صادر شده است؛ «دموی ساختگیِ وزن‌های مدل» نیست. نمونه‌های کوچکِ دستی دیگر، صریحاً دستی برچسب خورده‌اند.

[بستهٔ مستقل پروژه](dist/downloads/mini-gpt-project.zip) کد، آزمون‌های مدل، دادهٔ نمونه و راهنماها را دارد. اگر README را داخل ZIP می‌خوانید، پوشهٔ کتاب و ابزار ساخت در آن بسته نیست؛ برای اجرا، `mini_gpt/README.md` را دنبال کنید. آزمون مثال‌های کتاب در بستهٔ مستقل کنار گذاشته می‌شود.

## ساختار و ویرایش

```text
index.html                     ورودی کوتاه
dist/index.html                فهرست اصلی کتاب
dist/part-XX/chapter-YY/*.html  هر درس یک فایل
dist/part-XX/checkpoint.html   ایستگاه عملی بخش
dist/answers/                 پاسخ‌های جدا
dist/glossary/                صفحه‌های مفهوم و پیوندهای مرتبط
dist/code/                    مرجع همگام با فایل‌های پروژه
dist/assets/                  سبک و رفتار مشترک
book_src/part01.py … part10.py محتوای تألیفی درس‌ها
book_src/checkpoints.py        تکلیف و معیار عبور بخش‌ها
book_src/references.py         راهنما، واژه‌های کد و نقشهٔ پروژه
book_src/glossary.py           مفهوم‌های اصلی و تعریف‌های برگرفته از درس‌ها
book_src/terminology.py        یکدستی اصطلاح‌ها و پیونددهی فقط در متن
book_src/fonts/               قلم محلی و مجوز آن
book_src/experience.py        ترکیب درس و HTML آزمایشگاه/دفتر
book_src/experience.js        محاسبه‌های مرورگر و بازرس JSON
book_src/journal.js           دفتر و بازیابی پیش‌نویس‌ها
build_book.py                  تولید قطعی HTML و ZIP
mini_gpt/                     مدل و نسخه‌های آموزشی
tests/                        آزمون رفتار و مثال‌های کتاب
archive/edition-1.html         نسخهٔ نخست، بدون دست‌کاری
archive/edition-2-snapshot.zip سابقهٔ کامل پیش از تغییر سوم
data/inspection-sample.json   عددهای واقعیِ نمونهٔ همراه
```

برای ویرایش، منبع درس در `book_src` را تغییر دهید؛ فایل‌های HTML خروجی را دستی ویرایش نکنید. ساخت و بررسی پیوندها به PyTorch نیاز ندارد:

```sh
python build_book.py
python validate_book.py
node --check book_src/book.js
node tests/test_browser_math.js
node tests/test_journal.js
```

آزمون‌های JavaScript برای توسعه‌دهنده و نیازمند Node.js هستند؛ خود کتاب به Node نیاز ندارد. صفحات مرجع از فایل‌های واقعی ساخته می‌شوند؛ ۶۰ مثال مستقل درس نیز با آزمون Python اجرا می‌شوند. برای درس‌های دارای فرمان CLI، ابزارها در آزمون‌های مدل و اجرای واقعی بررسی می‌شوند، نه با تعبیر فرمان shell به Python.

## وضعیت و شواهد

- [نقشهٔ آموزشی](CURRICULUM.md)
- [ممیزی و تحلیل شکاف ویرایش سوم](GAP_ANALYSIS.md)
- [بازبینی نسخهٔ نخست و اصلاحات](REVIEW.md)
- [وضعیت دقیق، آزمون‌ها و محدودیت‌ها](PROGRESS.md)

مدل کوچک پروژه برای شناخت سازوکار است. کاهش خطا در یک اجرای کوتاه یا عبور از آزمون، به معنی کیفیت زبان عمومی یا درستی پاسخ‌های تولیدشده نیست.
