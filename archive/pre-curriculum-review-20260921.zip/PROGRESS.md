# Project status — final educational audit

## Current release — 2026-09-20

The educational audit and implementation are complete. The current book has
**74 lessons, 36 chapters, 10 parts, 84 progress units and 221 glossary entries**.
See [EDUCATIONAL_AUDIT.md](EDUCATIONAL_AUDIT.md) for changes and evidence,
[EDUCATIONAL_COVERAGE.md](EDUCATIONAL_COVERAGE.md) for all lesson decisions, and
[WINDOWS_SETUP.md](WINDOWS_SETUP.md) for the exact installation/startup procedure.

- Added `05a-vector-operations` and `12b-neuron`. Expanded probability/logarithms,
  derivatives, Backpropagation, Tensor shapes, PyTorch, Attention, Transformer
  assembly, training/debugging and experiments. Prerequisites precede abstract
  APIs; the full Attention lab follows masking, and beginner project labels no
  longer imply an architectural stage has already been built.
- Corrected technical terminology, output-head ambiguity, glossary examples and
  source context. Added independent-Test evaluation and UTF-8 Windows CLI output.
  The neural architecture and existing lesson URLs remain unchanged.
- Verification: **38 model/example tests**, including **64 executable lesson
  programs** and all 23 milestones; **29 release/editorial/design tests**;
  **29 JavaScript tests** and five syntax checks. All passed.
- The static validator checked **478 HTML pages, 47,739 local references and
  66 compiling Python files**. All 84 learning units fit at 320/768 px; all 221
  glossary pages fit at 320 px, including 165 expanded lesson-context panels.
- Tested a fresh Windows venv with Python 3.11.0 x64 and CPU PyTorch 2.14.0+cpu.
  The extracted model package passed 37 tests with one intentional book-source
  skip. Documented training, evaluation, generation, inspection and Resume ran;
  the six-step and four-plus-two recipes yielded identical saved model tensors.
- Independently compared all **487 public ZIP members** with `dist` and the
  manifest by size and SHA-256. Revalidated the extracted static site and served
  it with the documented root-directory command. The **2,536,890-byte**
  `release/book-site.zip` has SHA-256:
  `a490abb3c350c51079082e362f41e21e682c9e71b9b5ca19be527e215dfee2c5`.
- Removed six verified-unused CSS rules and the tool-created `.verification`
  tree: **679,931,783 bytes** of temporary dependencies, extracted test copies,
  synthetic fixtures, bytecode and diagnostics. Kept all user model runs, useful
  source/tests/data and history, including the pre-audit snapshot
  `archive/pre-educational-audit-20260920.zip`. Temporary preview servers stopped.
- Limits: existing Windows host, not a clean OS VM/installer test; no GPU/ARM
  verification. `file://` browser testing was blocked by tool policy; localhost
  was verified. Sites registration remains inaccessible (`NOT_FOUND`), so no
  remote publication or hosting metadata change occurred. The validated static
  archive is ready for deployment when hosting access is available.

## Historical records

The sections below describe earlier versions and their then-current counts and
checksums; they do not supersede the current release above.

## Connected glossary, navigation and typography — 2026-09-20

The latest extension is complete in `dist`; see `EDITORIAL_REVIEW.md` for the
implementation, review scope and limitations. The earlier visual-refactor and
model results below remain historical records.

- Every one of the 82 learning units has contextual next/previous navigation,
  parent-section return and a journey position. Chapter/part indexes, answers,
  glossary entries and major references also provide a clear next step.
- Added 213 connected concept pages: 49 authored core explanations plus 164
  definitions grounded in the existing lessons. English technical terminology
  is normalized in prose, with subtle links, searchable aliases, related
  concepts and exact lesson-location returns. Code, learner records and imported
  model data remain untouched by the editorial transformation.
- Bundled the official Vazirmatn variable font and license locally. Improved
  Persian hierarchy and spacing while keeping code in a separate monospace font.
- Browser checks covered all 82 units at 320/768 px and all 213 glossary pages
  at 320 px, with no page-width overflow. Verified glossary round-trips, search,
  collapsed-section returns, QKV/metrics views and separate code typography.
- Final release gate: **23 release/design/editorial tests, 29 JavaScript tests,
  five JavaScript syntax checks, 463 HTML pages, 41,428 local references, and
  60 compiling Python files**. All 472 archive members were independently
  compared with the manifest and `dist` by size and SHA-256.
- The 2,225,746-byte `release/book-site.zip` has SHA-256
  `6ba139c181e0dac6fce92c9bf0982275bed286de2fd8ba5f2a29fef263abcf10`.
  The pre-change snapshot remains at
  `archive/pre-connected-glossary-20260920.zip`.
- No model retraining, environment reinstallation, learner-data deletion or
  publication occurred. The configured Sites project still returns `NOT_FOUND`;
  its configuration and audience are preserved pending access recovery.

## Complete visual refactor — 2026-09-20

The active `dist` book now uses a new visual system, not the historical interface
described below. Review scope and limitations are recorded in `VISUAL_REVIEW.md`.

- Rebuilt page composition, typography, navigation, code, exercises, diagrams,
  progress presentation, lab stations, and responsive layouts. All 72 lessons
  have authored subject-specific briefs across twelve palettes and six opening
  compositions; diagrams carry explanatory captions.
- Preserved the educational sources, model code, all useful tools, stable URLs,
  progress/journal storage, answers and downloadable examples. The complete
  pre-refactor source/output snapshot is in
  `archive/pre-visual-refactor-20260920.zip`.
- Visually reviewed all 72 desktop openings, checked all lessons at 320 px and
  768 px, and inspected representative mobile/lower-page content. Fixed issues
  found in tensor diagrams, self-attention branching, cache explanation,
  constrained stacks, Persian labels, and narrow inline code.
- Added five design regression tests. Exact code text is preserved after syntax
  highlighting. The previous CPU model verification remains valid historical
  evidence; no PyTorch installation or new training run was needed for this pass.
- Final release gate passed: **15 release/design tests, 28 JavaScript tests,
  five JavaScript syntax checks, 250 HTML pages, 19,390 local references, and
  57 compiling Python files**. All 257 public archive members were independently
  checked by size and SHA-256. The 1,111,589-byte `release/book-site.zip` has SHA-256
  `9023eacaa553d0766d4874c5941b893f6c878c221c8e0251b45c219867966637`.
- Existing Sites project lookup returned `NOT_FOUND`. Its configuration was
  preserved and no remote deployment or new project was created. Resolve access
  before publishing. The release can be rebuilt with `python -B prepare_release.py`.

## Deployment preparation / environment cleanup — 2026-09-19

This maintenance note supersedes historical references below to temporary test
directories. The Persian textbook and model source have been preserved.

- Removed the tool-created `.test_dependencies` (PyTorch 2.5.1) and
  `.test_dependencies_v3` (PyTorch 2.14.0+cpu) installations after the final model
  verification: 1,939,988,221 bytes of disposable dependencies. Reinstall model
  dependencies in `.venv` using `requirements.txt` when needed; none are required
  to build or host the static textbook.
- Preserved all 122 QA files in `archive/authoring-qa-20260919.zip`; every member's
  SHA-256 was checked against its original before removing `.qa`. This private
  authoring backup is ignored by Git. Browser localStorage was not touched.
- Preserved `runs/verification`, `runs/review-verification`, both textbook edition
  archives, all authoring sources, model code and existing working-tree changes.
- Added `prepare_release.py`, ten deployment regression tests, and an English
  `DEPLOYMENT.md`. Builder/validator now accept explicit staging directories.
  Validation refuses optimized Python; release subprocesses clear PYTHONOPTIMIZE
  so assertions cannot silently disappear.
- A release starts with a clean temporary build, validates its full inventory,
  rejects unexpected existing `dist` files without deleting them, checks all five
  generated JS scripts, and creates a deterministic public-only ZIP plus hashes.
  Linked/reparse output paths and private/cache/training files are rejected.
- Verified: **33 model/lesson Python tests, 28 JavaScript tests, 10 release tests,
  and the Mini-GPT smoke test passed**. Static validation covers 250 HTML pages,
  18,890 local references and 55 Python source files. All 257 release ZIP members
  were independently checked against the manifest by size and SHA-256.
- `release/book-site.zip` is 1,097,760 bytes. Repeated builds before/after dependency
  removal produced SHA-256
  `04515c9e71c6ba797d18a1c144a8fc2cfc1b9d8dec332f541a45bc443c17dd78`.
  Determinism is scoped to the same Python/zlib/platform build environment.
- Existing `.openai/hosting.json` still selects the same Sites project and `dist`.
  The hosting execution-profile check required no changes. Only `dist` should be
  served; the portable ZIP is not the Sites-specific publishing archive.
- No remote deployment, audience change, upload, Git commit/push, or production
  server was started. Live HTTPS behavior and hosting response headers remain a
  post-publication check. GPU verification remains out of scope.

Rebuild the deployment bundle with `python -B prepare_release.py`. The next step,
when the user requests publishing, is the existing Sites hosting workflow with
the current audience preserved. Do not reconstruct the book or restore temporary
dependency directories just to deploy it.

---

آخرین بازبینی: ۲۰۲۶-۰۹-۱۹. نسخهٔ فعال `dist/index.html` است؛ منبع درس‌ها در `book_src` و مدل در `mini_gpt` قرار دارد. کار ضروری باز یا جای‌نگهدار اجرایی باقی نمانده است. مطالب پس از «سابقهٔ نسخهٔ دوم» فقط شواهد تاریخی‌اند.

## ممیزی، بازنویسی و حفظ سابقه

- پیش از تغییر، همهٔ۶۷ درس/پاسخ،۱۰ایستگاه، فایل‌های مدل/نسخه/آزمون، راهنما، سازنده و CSS/JS خوانده شد. baseline:۲۴ آزمون و۲۳۵صفحه سالم. گزارش شکاف و تصمیم‌ها: `GAP_ANALYSIS.md`.
- اصل نسخهٔ دوم، پیش از ویرایش در `archive/edition-2-snapshot.zip` محفوظ است؛ نسخهٔ اول نیز دست‌نخورده ماند. هر۶۷مسیر قدیمی درس با مسیر موجود در ZIP تطبیق داده شد و بدون تغییر است.
- هر۱۰بخش بازنویسی و پس از تغییر، کامل دوباره خوانده شد. بخش‌های۱–۴ یک بازبینی مستقل فنی دیگر نیز داشتند. عنوان‌ها/تمرین‌ها مسئله‌محورترند؛ اصطلاح‌ها در محل معرفی و پاسخ‌ها همچنان جدا هستند.
- پنج درس تازه: `01-learning`، `12-sgd`، `26b-sequence-memory`، `49b-schedule`، `65b-lora`. NLL، نشانه‌بند فایل‌پذیر، BPE واقعیِ آموزشی فارسی/انگلیسی، قرارداد داده، بازرسی و عیب‌یابی تقویت شدند.
- حاصل: **۷۲درس،۳۵فصل،۱۰بخش،۱۰ایستگاه،۸۲واحد پیشرفت،۲۵۰صفحه HTML و۶۰مثال مستقل Python**. شمارهٔ نشست با شناسهٔ ثابت درس جداست تا ارجاع‌های قبلی مبهم نشوند.
- هر۱۰ایستگاه و راهنما/نقشهٔ پروژه/API با سرفصل و CLI تازه هماهنگ شدند. دو دورهٔ هوسم فقط معیار سرفصل بودند؛ صفحهٔ مکتب‌خونه با وب و مرورگر فقط پوسته نشان داد و سرفصلش حدس زده نشد.

## تجربهٔ تازهٔ کتاب

- سه فضای متصل: مطالعه، آزمایشگاه و دفتر. اطلس بستهٔ بازشدنی با جست‌وجوی عنوان، ریل مرحلهٔ پروژه، قبلی/بعدی و ادامه از آخرین درس؛ بدون سایدبار دائمی.
- ترکیب هدفمند درس‌ها: مفهوم، محاسبه، ساخت، بررسی خطا و تأمل؛ رنگ معنایی، کد/فرمول LTR، متن RTL، چاپ و کاهش حرکت.
- چهار میز تعاملی: نقطه‌کد/شناسه/نمایش دستی؛ softmax/دما/خطای هدف؛ QKV/پوشش/جمع وزن‌دار؛ شکل محورها و هزینهٔ امتیاز توجه.
- نقشهٔ کامل GPT و نمودار SVG دو میان‌بر **Pre-Norm**. تشبیه «فکرکردن» به محاسبهٔ توزیع محدود شده، نه ذهن انسانی.
- بازرس با هفت نما: نمایش‌ها، QKV، امتیازها، پوشش/وزن، امتیاز و احتمال واژگان، چهار گام تولید، منحنی و جدول آموزش. ماتریس گرد‌شده برای خواندن و عدد کاملِ بازشدنی برای وارسی؛ هیچ دادهٔ واقعی با عدد ساختگی جایگزین نشده است.
- دفتر مرورگر: زمینهٔ درس، تنظیمات، پیش‌بینی، شاهد، تفسیر و پرسش؛ پیش‌نویس‌های جدا و بازیابی، ذخیرهٔ یادداشت، جست‌وجو، ورود/خروجی، نگهداری هر دو نسخهٔ ناسازگار. Web Locks در مرورگر پشتیبان، ثبت‌های هم‌زمان را هماهنگ می‌کند؛ نبود آن هشدار دارد.
- پیشرفت قدیمی مهاجرت می‌کند. HTTP با ذخیرهٔ سالم به نشانی کهنه تقدم می‌دهد؛ fallback فایل/ذخیرهٔ مسدود، زمانِ انجام و لغو را در پیوند حمل می‌کند. دانلود مسدود، جایگزین متنی دارد.

## Mini-GPT و شواهد اجرایی نسخهٔ سوم

- هستهٔ درست قبلی حفظ شد: شیفت هدف، split پیش از vocab، توجه علّی، مقیاس، Pre-Norm، ارزیابی وزن‌دار، sampling و ادامهٔ RNG.
- مسیر اختیاری trace در **همان forward** ثبت می‌شود؛ صادرکننده `mini_gpt.inspect` فایل JSON استاندارد بدون NaN/Infinity می‌سازد. لایه/سر/زمینه/تولید انتخاب‌پذیر است؛ فایل موجود بی‌اجازه بازنویسی نمی‌شود.
- برنامهٔ نرخ ثابت یا warmup/cosine با افق صریح و مستقل از تعداد گامِ توقف، در metadata ذخیره و در ادامه بازیابی می‌شود. گزارش ستون نرخ دارد؛ ادامهٔ گزارش قدیمی نیز سازگار است.
- ۲۳مرحلهٔ `mini_gpt.milestones` از قطعه‌های مشترک استفاده می‌کنند و همگی اجرا شدند. v0–v8 با برچسب مسیر قدیمی باقی ماندند. ابزار normalization اثر تعویض LayerNorm با Identity را به‌صورت آزمایش محدود گزارش می‌کند.
- حداقل PyTorch۲.۶ است؛ توصیهٔ آسیب‌پذیر۲.۵.۱ حذف شد. محیط آزمون فعلی: **Windows، Python۳.۱۱، PyTorch۲.۱۴.۰+cpu** در `.test_dependencies_v3`؛ وابستگی آزمون وارد ZIP نمی‌شود.
- **۳۳/۳۳ آزمون Python موفق**؛ آزمون درس‌ها هر۶۰مثال مستقل را اجرا می‌کند. **۲۸ آزمون Node موفق**:۸ محاسبه/قرارداد بازرس و۲۰ دفتر. نحو هر اسکریپت نیز بررسی شد.
- ادامهٔ CPU با dropout و برنامهٔ نرخ: وزن‌های۳+۵گام دقیقاً با۸گام پیوسته برابر؛ افق کاهش۶ باقی می‌ماند حتی وقتی آموزش تا۸ ادامه دارد. تست قدیمی۴+۲ در برابر۶ نیز عبور کرد.

اجرای واقعی در `runs/review-verification`: ابتدا۸۰گام و سپس ادامه تا۱۰۰، `T=16,C=32,H=4,L=2,B=8`،۲۸۵۴۴پارامتر و۴۰نشانه؛ نرخ پایه۰٫۰۰۳، warmup۱۰، افق کاهش۸۰، نسبت کف۰٫۱، یک thread روی CPU.

| گام | خطای دستهٔ آموزش | خطای ارزیابی |
|---:|---:|---:|
| ۱ | 3.694030 | 3.678715 |
| ۲۰ | 3.037993 | 3.000384 |
| ۴۰ | 2.827365 | 2.911144 |
| ۶۰ | 2.682735 | 2.842624 |
| ۸۰ | 2.742882 | 2.810641 |
| ۱۰۰ | 2.683254 | 2.809323 |

ارزیابی مستقل: perplexity=16.5987 و ناشناخته۱٫۴۴۹٪. تولید همچنان نامنسجم بود؛ این شاهد سلامت مسیر یادگیری است، نه کیفیت عمومی. `data/inspection-sample.json` با hash فایل واقعی، بازاجرای همهٔ عددهای forward، هر۴گام تولید با بذر۱۳۳۷ و CSV همان اجرا **دقیقاً برابر** شد.

## بسته، رابط و آزمون نهایی

- `validate_book.py`: **۲۵۰صفحه،۷۲درس،۳۵فصل،۸۲واحد،۱۸۸۹۰پیوند/دارایی،۵۳فایل Python**؛ پیوند شکسته، شناسهٔ تکراری، ناوبری مفقود یا دارایی نمایشی اینترنتی ندارد.
- ZIP مستقل در `.qa/package-edition3-check` باز شد؛ مبدأ import از همان بسته تأیید و مخزن اصلی از مسیر import غایب بود.۳۲ آزمون موفق،۱ کنارگذاری مورد انتظار برای منبع کتابِ خارج از ZIP؛ smoke و CLI مرحله‌های۰ و۲۲ موفق. ساخت قطعی ZIP دوباره با hash یکسان تأیید شد.
- مرورگر HTTP محلی: خانه، درس مفهوم، توجه، پاسخ کد، بلوک/نمودار، آزمایشگاه و دفتر بررسی شدند. عرض‌های۳۲۰ و۳۹۰، عرض قابل استفاده/scroll برابر۳۰۵/۳۰۵ و۳۷۵/۳۷۵ داشتند؛ جدول و کد در ظرف خود اسکرول می‌شوند.
- ابزارها واقعاً دست‌کاری شدند: نویسهٔ ناشناخته، تغییر logits، برداشتن پوشش و C نامقسوم برH. نتایج عددی و پیام قرارداد درست بودند. هر۷نمای بازرسِ نمونه و فایل واردشده باز شد؛ فایل نامعتبر نمای سالم را نگه داشت.
- پیشرفت۱/۸۲ پس از حرکت و تازه‌سازی حفظ شد؛ خروجی ویرایش دوم به۳/۸۲ ادغام و فایل نامعتبر رد شد؛ JSON متنی خروجی درست بود.
- دفتر: پیش‌نویس با تازه‌سازی برگشت؛ پس از ثبت، خروجی draft=null بود. دو زبانه یک یادداشت را ویرایش کردند؛ پس از تازه‌سازی زبانهٔ اول، دو نسخهٔ متفاوت حفظ شدند. ورود تکراری۰ برگه افزود؛ ورود نامعتبر۳برگهٔ موجود را نگه داشت. رشتهٔ شبیه HTML به‌صورت متن بود و هیچ عنصر img نساخت. لاگ error/warn صفحات آزموده خالی بود.
- پنج خطای دفتر پیش از تحویل رفع شد: revision پیش‌نویس، ظرفیت۵۰۰، تاریخ نامعتبر، تکرار یادداشت هنگام restore و اشتراک مخرب پیش‌نویس زبانه‌ها. نمونه‌های آزمون مرورگر با عنوان QA در مبدأ محلی۸۰۰۰ باقی‌اند؛ دادهٔ شخصی وارد نشد و فایل‌های بازیابی‌شان در `.qa` محفوظ است.

## حدود روشن و کار اختیاری آینده

- GPU/CUDA، آموزش توزیع‌شده و برابری عددی بین دستگاه‌ها آزموده نشده‌اند.
- نمونهٔ داده بسیار کوچک است؛ آزمون کیفیت عمومی/خوانندهٔ واقعی انجام نشده است. KV cache، tokenizer تولیدی BPE، SFT/DPO/LoRA تولیدی و آموزش بزرگ توضیح داده شده‌اند، نه پیاده‌سازی کامل. مثال LoRA فقط آزمایش یک تبدیل رتبهٔ کم است.
- بازکردن `file://` به‌دلیل سیاست مرورگر داخلی قبلاً رد شد و دور زده نشد؛ QA بصری با HTTP محلی انجام شد. fallback پیوند از نظر کد بازبینی شده، نه آزمون بصری file-origin در همهٔ مرورگرها. دفتر با مبدأ ثابت HTTP توصیه می‌شود.
- کاهش حرکت در CSS پیاده و بازبینی شد؛ شبیه‌سازی ترجیح سیستم در ابزار مرورگر موجود نبود. کپی/دانلود وابسته به اجازهٔ مرورگرند؛ متن قابل انتخاب/خروجی قابل کپی موجود است.
- پشتیبان دفتر شامل همهٔ برگه‌های ثبت‌شده و فرم فعلی است؛ برای پیش‌نویس زبانهٔ دیگر نخست آن را بازیابی کنید. پاک‌کردن دادهٔ مرورگر بدون خروجی قابل جبران نیست.
- این نسخه محلی است؛ چیزی به سرویس میزبانی منتشر یا آپلود نشده است. برای ادامه از همین منابع و شواهد استفاده کنید؛ بازسازی از صفر لازم نیست.

---

# سابقهٔ نسخهٔ دوم

آخرین به‌روزرسانی: ۲۰۲۶-۰۹-۱۹. بازسازی محلی کتاب و پروژه تکمیل شده است. وضعیت نسخهٔ نخست جایگزین شده؛ اصل آن در `archive/edition-1.html` محفوظ است.

## ساختار تکمیل‌شده

- ۱۰ بخش، ۳۵ فصل، ۶۷ درس مستقل و ۱۰ ایستگاه عملی؛ همهٔ درس‌های 01-model تا 67-rag نوشته و تولید شده‌اند.
- ۶۷ صفحهٔ پاسخ مستقل و ۱۰ راهنمای پاسخ ایستگاه؛ تمرین پیش از مرجع است.
- ۲۳۵ صفحهٔ HTML در خروجی: فهرست، راهنماها، درس‌ها، پاسخ‌ها، فصل/بخش و مرجع کد.
- اصطلاح‌های اصلی در زمینهٔ درس تعریف شده‌اند؛ واژه‌نامه به محل نخستین توضیح برمی‌گردد. راهنمای APIها معنی و مثال قرارداد تابع‌های پروژه را می‌دهد.
- ۵۴ مثال مستقل Python، تکلیف ساخت، پرسش تأمل، ارتباط با پروژه، دفتر یادگیری و مرور فاصله‌دار.
- هر ایستگاه چهار سطح مفهومی/محاسباتی/پیاده‌سازی/پژوهشی با تحویل و معیار عبور دارد.
- فهرست سلسله‌مراتبی، مسیر صفحه، بخش/فصل، قبلی/بعدی، کپی، نمایش باریک و پیشرفت انتخابی کاربر.
- ۷۷ واحد پیشرفت؛ ذخیرهٔ محلی، انتقال در پیوندها، ورود JSON معتبر و خروجی فایل همراه نسخهٔ متنیِ قابل کپی.
- منبع تألیفی در `book_src/`؛ ساخت قطعی با `build_book.py`؛ مرجع کد از فایل‌های واقعی خوانده می‌شود.
- راهنمای مفصل فارسی پروژه، نقشهٔ نسخه‌ها، نمودار معماری و بستهٔ ZIP مستقل آماده‌اند.

## وضعیت بخش‌ها

| بخش | درس‌ها | وضعیت |
|---|---|---|
| ۱ | 01–04 | نوشته، پیوندها بررسی، مثال‌ها اجرا شده |
| ۲ | 05–12 | محاسبات ضرب، softmax، خطا و مشتق مرور و مثال‌ها اجرا شده |
| ۳ | 13–20 | APIها، محورها و شبکهٔ غیرخطی اجرا شده |
| ۴ | 21–26 | واژگان آموزش‌محور، شیفت و نمایش اجرا شده |
| ۵ | 27–34 | مثال غیرمتقارن توجه و آزمون علّیت اجرا شده |
| ۶ | 35–42 | تقسیم/ادغام، پیش‌خور، نرمال‌سازی و بلوک اجرا شده |
| ۷ | 43–46 | شمار پارامتر، خطا و مسیر مشتق اجرا شده |
| ۸ | 47–53 | آموزش، ارزیابی، ذخیره و ادامه روی CPU اجرا شده |
| ۹ | 54–62 | تولید، نمونه‌گیری، حذف جزء و حفظ یک دسته اجرا شده |
| ۱۰ | 63–67 | توضیح محدودیت مقیاس و پس‌آموزش مرور؛ مثال بازیابی ساده اجرا شده |

درس نیمه‌نوشته یا جای‌نگهدار باز باقی نمانده است. منبع درس‌ها نسخهٔ قابل ویرایش است؛ خروجی HTML را دستی تغییر ندهید.

## Mini-GPT تکمیل‌شده

- v0 شمارشی بدون PyTorch؛ نگاشت سادهٔ درس ۲، بدون معرفی زودهنگام ناشناخته.
- v1 نمایش و خروجی؛ v2 توجه تک‌سرِ عمداً بی‌پوشش؛ v3 اصلاح علّی؛ v4 چندسر و موقعیت؛ v5 یک بلوک؛ v6 مدل چندبلوکی؛ v7 ابزار آموزش؛ v8 تولید.
- مدل: نمایش نویسه/موقعیت، بلوک‌های Pre-Norm، توجه صریح، شبکهٔ پیش‌خور، دو مسیر جمع، نرمال‌سازی نهایی و خروجی بدون bias.
- قراردادهای شکل، نوع، شناسه و دستگاه با پیام روشن کنترل می‌شوند؛ ورودی اعشاریِ شناسه به‌طور خاموش گرد نمی‌شود.
- واژگان فقط پس از جداسازی متن و از بخش آموزش ساخته می‌شود؛ اثر انگشت پیکره و نرخ ناشناخته ثبت می‌شود.
- ارزیابی بر تعداد هدف‌ها وزن می‌گیرد؛ حالت مدل را بازیابی می‌کند.
- checkpoint قالب ۲ مستقل شامل واژگان، معماری، وزن‌ها، بهینه‌ساز و حالت‌های تصادف؛ بارگذاری با weights_only=True.
- آخرین/بهترین فایل و metrics.csv؛ ادامه فقط از last.pt همان پوشه و با گام گزارش سازگار، بدون بازنویسی خاموش اجرای دیگر.
- دما، انتخاب حریصانه، k دقیق در تساوی و p با نگهداری گزینهٔ رسیدن/عبور از آستانه؛ کنترل ورودی نامعتبر.

## شواهد اجرای واقعی

محیط: Windows، Python 3.11، PyTorch 2.5.1+cpu. بستهٔ آزمون در `.test_dependencies/` محلی و خارج از خروجی توزیع‌شده است.

۱. `python -m unittest discover -s tests -v`: **۲۴ آزمون موفق، بدون رد یا کنارگذاری در مخزن اصلی**. یکی از این آزمون‌ها هر ۵۴ مثال مستقل کتاب را اجرا می‌کند. پوشش: علّیت، شکل غیرمربعی، احتمال قبل از dropout، مشتق همهٔ پارامترها، شیفت، واژگان مستقل، میانگین وزن‌دار، نمونه‌گیری و مرز دقیق p، تولید زمینهٔ بلند، بارگذاری، ادامهٔ دقیق و رد داده/گزارش ناسازگار.

۲. `python -m mini_gpt.smoke_test`: موفق؛ نگاشت، forward، loss، backward و تولید.

۳. آزمایش حفظ یک دسته: خطا از **2.4517 به 0.0053** در ۸۰ گام رسید؛ این آزمون سلامت یادگیری است، نه تعمیم.

۴. آزمون CPU با حذف تصادفی فعال: وزن‌های اجرای **۴+۲ گام دقیقاً برابر ۶ گام پیوسته** بودند. ارزیابی مولد تصادفی جدا دارد تا مسیر آموزش را عوض نکند.

۵. اجرای واقعی روی `data/sample.txt` از فرمان v7 با `T=16,C=16,H=2,L=1,B=8,lr=0.003,threads=1` در `runs/verification`:

| گام | خطای دستهٔ آموزش | خطای ارزیابی |
|---:|---:|---:|
| ۱ | 3.6895 | 3.6649 |
| ۱۰ | 3.4141 | 3.4068 |
| ۲۰ | 3.1799 | 3.1429 |
| ۳۰ | 3.0146 | 2.9963 |
| ۳۵، پس از ادامه از فایل | 2.9272 | 2.9396 |

مدل ۴۸۴۸ پارامتر و ۴۰ نشانه داشت؛ نرخ ناشناختهٔ ارزیابی ۱٫۴۴۹٪ بود. ارزیابی مستقل در گام ۳۰ مقدار `2.996328` و perplexity برابر `20.0119` داد. تولید حریصانه، top-k و top-p از checkpoint واقعی اجرا شدند. خروجی کوتاه هنوز نامنسجم/تکراری بود؛ ادعای کیفیت عمومی نداریم.

۶. ZIP مستقل در پوشهٔ جدا باز و آزموده شد: آزمون‌های مدل موفق؛ آزمون مثال‌های کتاب طبق قرارداد، چون منبع کتاب در ZIP نیست، کنار گذاشته می‌شود. smoke test و نسخهٔ صفر نیز در بسته اجرا شدند.

## شواهد کتاب و مرورگر

- `python validate_book.py`: همهٔ ۲۳۵ صفحه، ۷۷ واحد، پیوند/دارایی‌های محلی و ۴۸ فایل Python بررسی شدند؛ هدف محلی شکسته، شناسهٔ تکراری یا وابستگی نمایشی اینترنتی یافت نشد.
- `node --check book_src/book.js`: موفق.
- ساخت دوبارهٔ بستهٔ پروژه، SHA-256 یکسان داد؛ خروجی ZIP قطعی است. اثر Git نسخهٔ بایگانی نیز دقیقاً با index.html نسخهٔ پیش از بازسازی برابر بود.
- پیش‌نمایش HTTP روی 127.0.0.1:8000، فقط رایانهٔ محلی؛ از اینترنت یا سرویس بیرونی استفاده نمی‌کند.
- خوانایی درس اول در اندازهٔ معمول مرورگر؛ کد و فرمول LTR و متن RTL بررسی شد.
- اندازهٔ موبایل ۳۹۰×۸۴۴: منوی بستهٔ بازشدنی، پاسخ نمونه، فرمول غیرمتقارن و صفحهٔ معماری بررسی شدند. عرض قابل استفاده و scrollWidth هر دو ۳۷۵ پیکسل بودند؛ اسکرول افقی صفحه ایجاد نشد. کد و نمودار می‌توانند داخل جعبهٔ خود اسکرول شوند.
- علامت انجام، حرکت به درس بعد و تازه‌سازی: شمارنده ۱/۷۷ حفظ شد. فایل معتبر به ۳/۷۷ ادغام شد؛ شناسهٔ نامعتبر رد شد.
- دکمهٔ کپی پیام موفق نشان داد. خروجی JSON در خود صفحه و ورود مجدد آن بررسی شد. مرورگر داخلی رویداد دانلود فایل Blob را گزارش نکرد؛ به همین دلیل مسیر مستقلِ متن JSON قابل کپی افزوده شد و محتوایش تأیید شد. ذخیرهٔ فایل دانلودشده در همهٔ مرورگرها ادعا نمی‌شود.
- لاگ خطا/هشدار مرورگر در صفحات آزموده خالی بود. وضعیت پیشرفت آزمایشی به حالت خالی بازگردانده شد.

## محدودیت‌ها و کارهای بعدیِ اختیاری

- GPU/CUDA و نسخه‌های دیگر PyTorch آزموده نشده‌اند؛ برابری دقیق ادامه فقط برای محیط CPU همسان تأیید شده است.
- ابزار مرورگر داخلی طبق سیاست امنیتی بازکردن `file://` را نپذیرفت؛ این مسیر با ابزار به‌صورت بصری آزموده نشد و دور زده نشد. ساختار بدون fetch و وابستگی بیرونی است؛ روش HTTP محلیِ راهنما آزموده شده است.
- کپی به کلیپ‌بورد و دانلود به مجوزهای مرورگر وابسته است؛ انتخاب دستی کد و نسخهٔ متنی پیشرفت راه جایگزین‌اند.
- کتاب برای کار آفلاین ساخته شده، ولی نصب اولیهٔ PyTorch اینترنت می‌خواهد.
- سنجش کیفیت بلندمدت با خوانندگان واقعی انجام نشده است؛ بازخورد آموزشی می‌تواند ویرایش‌های بعدی را هدایت کند.
- دادهٔ نمونه کوچک و تکراری است؛ آزمون نهایی جدا، آموزش بزرگ، نشانه‌بندی زیرواژه‌ای، حافظهٔ K/V و تنظیم دستوری در این نسخه پیاده نشده‌اند. مرز توضیح نظری و قابلیت اجرایی روشن است.
- انتشار بیرونی انجام نشده است. خروجی حاضر فایل‌های محلی کتاب و پروژه است.

کارهای بعدی برای خواننده: نخستین ایستگاه را انجام دهد، دفتر را شخصی کند، سپس یک تغییر کوچک همراه با آزمون اضافه کند. هیچ‌یک از این آزمایش‌های شخصی شرط استفاده از نسخهٔ تکمیل‌شده نیست.
