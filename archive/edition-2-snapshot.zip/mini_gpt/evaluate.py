"""ارزیابی همهٔ هدف‌ها با وزن برابر؛ بدون تغییر پارامترها."""

import argparse
import math

import torch
from torch.utils.data import DataLoader

from .checkpoint import load_checkpoint
from .dataset import NextTokenDataset
from .runtime import resolve_device


@torch.no_grad()
def evaluate(model, loader, device, max_batches=None):
    was_training = model.training
    model.eval()
    total_loss, total_tokens = 0.0, 0
    try:
        for index, (inputs, targets) in enumerate(loader):
            if max_batches is not None and index >= max_batches:
                break
            _, loss = model(inputs.to(device), targets.to(device))
            count = targets.numel()
            total_loss += loss.item() * count
            total_tokens += count
    finally:
        model.train(was_training)
    if total_tokens == 0:
        raise ValueError("evaluation loader contains no target tokens")
    return total_loss / total_tokens


def main():
    from .data import prepare_corpus
    parser = argparse.ArgumentParser(description="Evaluate a MiniGPT checkpoint on the held-out tail")
    parser.add_argument("--checkpoint", default="checkpoints/best.pt")
    parser.add_argument("--text", default="data/sample.txt")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="cpu")
    parser.add_argument("--threads", type=int, default=2)
    args = parser.parse_args()
    if args.threads < 1 or args.batch_size < 1:
        raise ValueError("threads and batch_size must be positive")
    torch.set_num_threads(args.threads)
    device = resolve_device(args.device)
    model, tokenizer, payload = load_checkpoint(args.checkpoint, device)
    _, valid_ids, _, metadata = prepare_corpus(args.text, payload["metadata"]["train_fraction"], tokenizer)
    if metadata["corpus_sha256"] != payload["metadata"]["corpus_sha256"]:
        raise ValueError("corpus differs from training; use the original file for held-out evaluation")
    loader = DataLoader(NextTokenDataset(valid_ids, model.config.context_length), batch_size=args.batch_size)
    loss = evaluate(model, loader, device)
    perplexity = math.exp(loss) if loss < 700 else float("inf")
    print(f"validation_loss={loss:.6f} perplexity={perplexity:.4f} unknown_rate={metadata['validation_unknown_rate']:.4f}")


if __name__ == "__main__":
    main()
