"use strict";
(() => {
  const manifest = window.BOOK;
  const allowed = new Set(manifest.units.map(x => x.id));
  const key = "mini-gpt-book-edition-2";
  let completed = new Set();
  let storageOK = true;
  const valid = items => Array.isArray(items) && items.every(x => typeof x === "string" && allowed.has(x));
  try {
    const saved = JSON.parse(localStorage.getItem(key) || "[]");
    if (valid(saved)) saved.forEach(x => completed.add(x));
  } catch (_) { storageOK = false; }
  // file:// persistence differs across browsers. Explicit URL state carries progress across pages.
  const incoming = new URL(location.href).searchParams.get("done");
  if (incoming !== null) {
    const ids = incoming ? incoming.split(",") : [];
    if (valid(ids)) completed = new Set(ids);
  }
  const status = message => {
    const target = document.querySelector("[data-status]");
    if (target) target.textContent = message;
  };
  function render() {
    const ids = [...completed].sort();
    try { localStorage.setItem(key, JSON.stringify(ids)); } catch (_) { storageOK = false; }
    document.querySelectorAll("[data-progress-count]").forEach(x => x.textContent = `${ids.length} / ${allowed.size}`);
    document.querySelectorAll("progress").forEach(x => { x.max = allowed.size; x.value = ids.length; });
    document.querySelectorAll("[data-unit]").forEach(x => x.classList.toggle("completed", completed.has(x.dataset.unit)));
    const button = document.querySelector("[data-complete]");
    if (button) {
      const done = completed.has(button.dataset.complete);
      button.setAttribute("aria-pressed", String(done));
      button.textContent = done ? "✓ انجام شد؛ برای لغو کلیک کنید" : "تمرین و خودسنجی را انجام دادم";
    }
    document.querySelectorAll("a[data-book-link]").forEach(a => {
      const url = new URL(a.getAttribute("href"), location.href);
      url.searchParams.set("done", ids.join(","));
      a.href = url.href;
    });
    // Keep the current URL in sync so a refresh or bookmark does not undo a toggle.
    const current = new URL(location.href);
    current.searchParams.set("done", ids.join(","));
    try { history.replaceState(null, "", current); } catch (_) { /* file browsers may disallow this */ }
    if (!storageOK) status("ذخیرهٔ مرورگر در دسترس نیست؛ پیشرفت در پیوندها منتقل می‌شود. نسخهٔ JSON بگیرید.");
  }
  document.querySelector("[data-complete]")?.addEventListener("click", event => {
    const id = event.currentTarget.dataset.complete;
    completed.has(id) ? completed.delete(id) : completed.add(id);
    render();
  });
  document.querySelectorAll("pre").forEach(pre => {
    const wrapper = document.createElement("div"); wrapper.className = "codebox";
    pre.parentNode.insertBefore(wrapper, pre); wrapper.append(pre);
    const button = document.createElement("button"); button.type = "button"; button.textContent = "کپی کد";
    wrapper.insertBefore(button, pre);
    button.addEventListener("click", async () => {
      try {
        if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(pre.textContent);
        else {
          const area = document.createElement("textarea"); area.value = pre.textContent;
          area.style.position = "fixed"; area.style.opacity = "0"; document.body.append(area); area.select();
          const ok = document.execCommand("copy"); area.remove(); if (!ok) throw new Error("copy denied");
        }
        button.textContent = "کپی شد";
      } catch (_) {
        const range = document.createRange(); range.selectNodeContents(pre);
        const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
        button.textContent = "انتخاب شد؛ Ctrl+C بزنید";
      }
    });
  });
  document.querySelector("[data-export]")?.addEventListener("click", () => {
    const serialized = JSON.stringify({ edition: 2, completed: [...completed].sort() }, null, 2);
    const preview = document.querySelector('[data-export-preview]');
    preview.hidden = false; preview.open = true;
    document.querySelector('[data-export-code]').textContent = serialized;
    const url = URL.createObjectURL(new Blob([serialized], { type: "application/json" }));
    const a = document.createElement("a"); a.href = url; a.download = "learning-progress.json"; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    status("نسخهٔ پیشرفت آماده شد؛ اگر دانلود مرورگر مسدود است، JSON بخش «نسخهٔ متنی» را کپی کنید.");
  });
  document.querySelector("[data-import]")?.addEventListener("change", async event => {
    const file = event.target.files[0]; if (!file) return;
    try {
      if (file.size > 50000) throw new Error("large file");
      const data = JSON.parse(await file.text());
      if (data.edition !== 2 || !valid(data.completed)) throw new Error("invalid data");
      data.completed.forEach(x => completed.add(x)); render(); status("پیشرفت وارد و با وضعیت فعلی ادغام شد.");
    } catch (_) { status("فایل پیشرفت معتبر نیست؛ فقط خروجی JSON همین ویرایش را وارد کنید."); }
    event.target.value = "";
  });
  if (matchMedia("(min-width: 701px)").matches) document.querySelector(".sidebar>details")?.setAttribute("open", "");
  render();
})();
