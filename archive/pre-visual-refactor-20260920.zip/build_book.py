"""ساخت قطعی کتاب ایستا از محتوای درس‌ها؛ بدون وابستگی خارجی."""

import argparse
import html
from html.parser import HTMLParser
import importlib
import json
import os
from pathlib import Path
import re
import zipfile

from book_src.checkpoints import CHECKPOINTS
from book_src.schema import PARTS
from book_src.experience import (INLINE_LABS, JOURNAL, MODE_LABELS, lab_page,
                                 lesson_mode, pipeline, stage_for)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "dist"
LESSONS = [lesson for part in range(1, 11)
           for lesson in importlib.import_module(f"book_src.part{part:02}").LESSONS]
BY_ID = {lesson.id: lesson for lesson in LESSONS}
CHAPTERS = {}
PATHS = {}
for lesson in LESSONS:
    key = (lesson.part, lesson.chapter)
    if key not in CHAPTERS:
        number = len([k for k in CHAPTERS if k[0] == lesson.part]) + 1
        CHAPTERS[key] = (f"part-{lesson.part:02}/chapter-{number:02}/index.html", [])
    chapter_path, chapter_lessons = CHAPTERS[key]
    chapter_lessons.append(lesson)
    PATHS[lesson.id] = str(Path(chapter_path).with_name(lesson.id + ".html")).replace("\\", "/")
UNITS = []
for part in range(1, 11):
    UNITS.extend((l.id, PATHS[l.id], l.title) for l in LESSONS if l.part == part)
    UNITS.append((f"checkpoint-{part:02}", f"part-{part:02}/checkpoint.html", f"ایستگاه عملی {part}"))


def escaped(value):
    return html.escape(str(value), quote=True)


def display_title(value):
    return escaped(value).replace('Mini-GPT', '<bdi dir="ltr" class="nowrap">Mini-GPT</bdi>').replace('Python', '<bdi dir="ltr">Python</bdi>')


class MathDirection(HTMLParser):
    """Keep inline ASCII arrays/shape tuples readable inside Persian paragraphs."""
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        self.parts.append(self.get_starttag_text())
        if tag in ('code', 'pre'):
            self.skip += 1

    def handle_endtag(self, tag):
        self.parts.append(f'</{tag}>')
        if tag in ('code', 'pre'):
            self.skip -= 1

    def handle_data(self, data):
        pattern = r'(?:\b[A-Za-z][A-Za-z0-9_]*=)?(?:\[[A-Za-z0-9_.,\[\] +*/=-]+\]|\([A-Za-z0-9_=,/*× .-]+\))'
        if not self.skip:
            data = re.sub(pattern, lambda m: '<bdi dir="ltr">'+m[0]+'</bdi>', data)
        self.parts.append(data)

    def handle_entityref(self, name):
        self.parts.append('&'+name+';')

    def handle_charref(self, name):
        self.parts.append('&#'+name+';')


def relative(current, target):
    return os.path.relpath(OUT / target, (OUT / current).parent).replace("\\", "/")


def link(current, target, label, unit=""):
    current_attr = ' aria-current="page"' if current == target else ""
    unit_attr = f' data-unit="{escaped(unit)}"' if unit else ""
    navigation_attr = ' data-book-link' if target.endswith('.html') else ''
    return (f'<a href="{escaped(relative(current, target))}"{navigation_attr}'
            f'{current_attr}{unit_attr}>{escaped(label)}</a>')


def lesson_link(current, lesson_id):
    return link(current, PATHS[lesson_id], BY_ID[lesson_id].title, lesson_id)


def sidebar(current, part):
    result = ['<nav class="atlas" aria-label="اطلس مسیر"><details><summary>اطلس کتاب <span>۱۰ بخش؛ مسیر را باز کنید</span></summary><div class="atlas-content"><label>پیداکردن درس <input type="search" data-lesson-search placeholder="مثلاً گرادیان یا attention"></label><div data-search-results aria-live="polite"></div><div class="atlas-grid">']
    for n, (title, _) in enumerate(PARTS, 1):
        result.append(f'<details{" open" if n == part else ""}><summary>بخش {n} · {escaped(title)}</summary>')
        result.append(link(current, f"part-{n:02}/index.html", "صفحهٔ بخش"))
        result.append("<ol>")
        for (p, chapter), (path, _) in CHAPTERS.items():
            if p == n:
                result.append(f"<li>{link(current, path, chapter)}</li>")
        result.append(f'<li>{link(current, f"part-{n:02}/checkpoint.html", "ایستگاه عملی", f"checkpoint-{n:02}")}</li></ol></details>')
    result.append('</div></div></details></nav>')
    return "".join(result)


def resolve(text, current):
    return re.sub(r'\[\[([a-zA-Z0-9][a-zA-Z0-9/_\-.]*)(?:\|([^]]+))?\]\]',
                  lambda m: link(current,PATHS.get(m[1],m[1]),m[2] or BY_ID[m[1]].title), text)


def page(current, title, body, *, part=0, crumbs=(), unit="", kind="reference"):
    trail = [link(current, "index.html", "خانه")]
    trail.extend(link(current, target, label) for target, label in crumbs)
    trail.append(f'<span aria-current="page">{escaped(title)}</span>')
    progress = (f'<details class="progress-panel"><summary>پیشرفت مسیر <span data-progress-count>0 / {len(UNITS)}</span></summary><div class="progress-tools"><progress value="0" max="{len(UNITS)}" aria-label="درس‌ها و ایستگاه‌های انجام‌شده"></progress>'
                '<button type="button" data-export>خروجی پیشرفت</button>'
                '<label class="import-label">ورود پیشرفت <input type="file" accept=".json,application/json" data-import></label></div>'
                '<details data-export-preview hidden><summary>نسخهٔ متنی پیشرفت؛ اگر دانلود انجام نشد، این JSON را کپی و در فایل نگه دارید</summary><pre><code data-export-code></code></pre></details>'
                '<p class="progress-note">علامت انجام فقط با انتخاب شما ثبت می‌شود. برای نگهداری مطمئن یا انتقال به مرورگر دیگر، خروجی پیشرفت بگیرید. دفتر آزمایش جداست.</p>'
                '<p class="status" role="status" aria-live="polite" data-status></p></details>')
    completion = (f'<button class="done-button" data-complete="{escaped(unit)}" aria-pressed="false">'
                  'تمرین و خودسنجی را انجام دادم</button>') if unit else ""
    body = resolve(body, current)
    body = re.sub(r"<table>(.*?)</table>", r'<div class="table-wrap"><table>\1</table></div>', body, flags=re.S)
    direction = MathDirection()
    direction.feed(body)
    body = ''.join(direction.parts)
    mode = lesson_mode(unit) if kind == 'lesson' else kind
    stage, stage_title = stage_for(unit) if kind == 'lesson' else (None, '')
    order = next((i+1 for i,l in enumerate(LESSONS) if l.id == unit), None)
    context = (f'<div class="context-rail"><span>{MODE_LABELS[mode]} · نشست {order} از {len(LESSONS)}</span><span>شناسهٔ ثابت: <bdi dir="ltr">{unit}</bdi></span><span>پروژه / مرحلهٔ {stage} · {stage_title}</span>{link(current,"project.html","بازگشت به ساخت")}</div>') if kind == 'lesson' else ''
    journal_target = relative(current, 'journal.html') + (f'?lesson={unit}' if unit else '')
    scripts = '<script src="'+relative(current,'assets/experience.js')+'" defer></script>'
    if current == 'lab.html':
        scripts = '<script src="assets/inspection-demo.js" defer></script>' + scripts
    if current == 'journal.html':
        scripts += '<script src="assets/journal.js" defer></script>'
    document = f'''<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escaped(title)} | از Python تا Mini-GPT</title><meta name="description" content="کتاب فارسیِ ساخت تدریجی یک مدل زبان؛ درس، آزمایش، کد و خودسنجی.">
<link rel="stylesheet" href="{relative(current, 'assets/book.css')}">
<script src="{relative(current, 'assets/manifest.js')}" defer></script><script src="{relative(current, 'assets/book.js')}" defer></script>{scripts}</head>
<body data-page-kind="{kind}" data-mode="{mode}" data-unit-id="{escaped(unit)}" data-root="{relative(current,'index.html')}"><a class="skip" href="#main">رفتن به متن</a>
<header class="topbar"><a class="brand" href="{relative(current,'index.html')}" data-book-link>از <bdi dir="ltr">Python</bdi> تا <bdi dir="ltr" class="nowrap">Mini-GPT</bdi></a>
<nav class="toplinks" aria-label="فضاهای کتاب">{link(current,'guide.html','آغاز')}{link(current,'lab.html','آزمایشگاه')}<a href="{journal_target}" data-book-link>دفتر آزمایش</a>{link(current,'project.html','پروژه')}{link(current,'glossary.html','واژه‌ها')}</nav></header>
<div class="navigation-shell">{sidebar(current,part)}</div><div class="layout"><main id="main"><nav class="breadcrumbs" aria-label="مسیر صفحه">{' <span aria-hidden="true">/</span> '.join(trail)}</nav>
{context}<header class="page-masthead"><p class="edition-mark">دفتر ساخت یک مدل زبان / ویرایش سوم</p><h1>{display_title(title)}</h1></header>{body}{completion}
<p class="journal-return"><a href="{journal_target}" data-book-link>یک شاهد از این صفحه در دفتر ثبت کنید ←</a></p>{progress}<footer class="footer"><span>کتاب، کارگاه، دفتر.</span> مطالعهٔ آفلاین · بدون سرویس یا قلم اینترنتی · {link(current,'api.html','مرجع کد و منابع')} · پاسخ مرجع بعد از کوشش شما.</footer></main></div>
<noscript><p>خواندن و ناوبری بدون JavaScript هم کار می‌کند؛ کپی خودکار و ثبت پیشرفت به آن نیاز دارند.</p></noscript></body></html>'''
    destination = OUT / current
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(document, encoding="utf-8")


def pager(current, unit):
    index = next(i for i, item in enumerate(UNITS) if item[0] == unit)
    previous = UNITS[index - 1] if index else ("", "guide.html", "راهنمای آغاز")
    following = UNITS[index + 1] if index + 1 < len(UNITS) else ("", "project.html", "پروژهٔ شخصی بعدی")
    return ('<nav class="pager" aria-label="قبلی و بعدی">' +
            link(current, previous[1], "← قبلی: " + previous[2], previous[0]) +
            link(current, following[1], "بعدی: " + following[2] + " →", following[0]) + "</nav>")


def code_block(code):
    return '<pre><code>' + escaped(code.strip()) + '</code></pre>'


def render_lessons():
    for lesson in LESSONS:
        path = PATHS[lesson.id]
        chapter_path, _ = CHAPTERS[(lesson.part, lesson.chapter)]
        crumbs = [(f"part-{lesson.part:02}/index.html", f"بخش {lesson.part}"), (chapter_path, lesson.chapter)]
        body = f'<p class="objective">{lesson.objective}</p><article class="lesson-prose">' + lesson.body + '</article>'
        if lesson.id in INLINE_LABS:
            body += INLINE_LABS[lesson.id]()
        body += f'<section class="task"><p class="section-number">نوبت شما</p><h2>یک پیش‌بینی، یک کوشش</h2><p>{lesson.task}</p>'
        body += f'<p>{link(path, "answers/" + lesson.id + ".html", "پس از کوشش: پاسخ و اجرای مرجع")}</p></section>'
        body += f'<section class="check"><h2>از کجا بفهمیم جا افتاده؟</h2><p>{lesson.check}</p></section>'
        body += f'<aside class="project"><h2>روی میز Mini-GPT</h2><p>{lesson.project}</p></aside>'
        if lesson.review:
            body += f'<p class="note">{lesson.review}</p>'
        body += pager(path, lesson.id)
        page(path, lesson.title, body, part=lesson.part, crumbs=crumbs, unit=lesson.id, kind="lesson")
        answer_path = f"answers/{lesson.id}.html"
        answer = '<p class="answers-warning">این صفحه را بعد از نوشتن پیش‌بینی و تلاش خودتان بخوانید. تفاوت پاسخ خود و مرجع را در دفتر ثبت کنید.</p>'
        answer += f'<h2>صورت تکلیف</h2><p>{lesson.task}</p><h2>مقایسه با مرجع</h2><p>{lesson.answer}</p>'
        if lesson.code:
            answer += f'<h2>اجرای مرجع</h2><p class="meta">{escaped(lesson.code_kind)}. فرمان را از ریشهٔ پروژه اجرا کنید. نام تازه‌ای دیدید؟ {link(answer_path,"api.html","راهنمای APIها و قرارداد نام‌ها")} را ببینید.</p>' + code_block(lesson.code)
        if lesson.source:
            source_path = "code/" + lesson.source + ".html"
            answer += f'<p>قطعهٔ مرتبط: {link(answer_path,source_path,lesson.source)}. فایل نهایی بخش‌های جلسه‌های بعد را هم دارد؛ خواندن کامل آن اکنون پیش‌نیاز نیست.</p>'
        answer += f'<p>{lesson_link(answer_path,lesson.id)} · {link(answer_path,"project.html","دریافت پروژه و دستور اجرا")}</p>'
        page(answer_path, "پاسخ: " + lesson.title, answer, part=lesson.part, crumbs=crumbs)


def render_structure():
    toc = []
    for n, ((part_title, description), checkpoint) in enumerate(zip(PARTS, CHECKPOINTS), 1):
        path = f"part-{n:02}/index.html"
        part_body = f'<p class="objective">{description}</p><p>هر درس یک نشست ۳۰ تا ۹۰ دقیقه‌ای پیشنهادی است؛ زمان تمرین ممکن است بیشتر شود. پس از کار عملی، یک روز فاصله بدهید و دوباره توضیح دهید.</p>'
        home_section = f'<section class="toc-part"><h2>{link("index.html",path,f"بخش {n} · {part_title}")}</h2><p class="meta">{description}</p>'
        for (part, title), (chapter_path, lessons) in CHAPTERS.items():
            if part != n:
                continue
            def items(current):
                return '<ol>' + ''.join(f'<li>{lesson_link(current,l.id)}</li>' for l in lessons) + '</ol>'
            part_body += f'<h2>{link(path,chapter_path,title)}</h2>' + items(path)
            home_section += f'<p class="route-chapter">{link("index.html",chapter_path,title)}</p>'
            chapter_body = '<p>این فصل را یک‌جا تمام نکنید. درس‌ها را به‌ترتیب بخوانید و پیش از پاسخ مرجع، چیزی بنویسید یا اجرا کنید.</p>' + items(chapter_path)
            chapter_body += '<h2>کارهایی که در این فصل انجام می‌دهید</h2><ul>'
            chapter_body += ''.join(f'<li>{l.task}</li>' for l in lessons) + '</ul>'
            chapter_body += '<p>کار چهارسطحیِ مفهومی، محاسباتی، ساخت و پژوهش با معیار تحویل مشخص در ' + link(chapter_path,f"part-{n:02}/checkpoint.html","ایستگاه این بخش") + ' منتظر شماست؛ پس از درس‌های بخش سراغ آن بروید.</p>'
            page(chapter_path,title,chapter_body,part=n,crumbs=[(path,f"بخش {n}")],kind="chapter")
        part_body += '<h2>پیش از بخش بعد</h2>' + link(path,f"part-{n:02}/checkpoint.html",checkpoint[0],f"checkpoint-{n:02}")
        page(path, f"بخش {n} · {part_title}",part_body,part=n,kind="part")
        home_section += f'<p>{link("index.html",f"part-{n:02}/checkpoint.html",checkpoint[0],f"checkpoint-{n:02}")}</p></section>'
        toc.append(home_section)
        cp_path = f"part-{n:02}/checkpoint.html"
        cp_title, revisit, tasks, criterion, answer = checkpoint
        cp_body = '<p class="objective">پایان این بخش، زمان آزمودن فهم است؛ نه صرفاً علامت‌زدن صفحه‌ها. برای این کار یک یا دو نشست مستقل بگذارید.</p>'
        cp_body += '<ol>' + ''.join(f'<li>{task}</li>' for task in tasks) + '</ol>'
        cp_body += f'<section class="check"><h2>معیار عبور</h2><p>{criterion}</p></section>'
        cp_body += '<p>اگر گیر کردید، از ' + lesson_link(cp_path,revisit) + ' برگردید و فقط قطعهٔ مبهم را بازسازی کنید.</p>'
        cp_body += '<p>' + link(cp_path,f"answers/checkpoint-{n:02}.html","پس از تحویل: راهنمای سنجش") + '</p>' + pager(cp_path,f"checkpoint-{n:02}")
        page(cp_path, f"ایستگاه {n} · {cp_title}",cp_body,part=n,crumbs=[(path,f"بخش {n}")],unit=f"checkpoint-{n:02}",kind="checkpoint")
        answer_path = f"answers/checkpoint-{n:02}.html"
        page(answer_path,f"راهنمای ایستگاه {n}",f'<p>{answer}</p><p>{criterion}</p><p>{link(answer_path,cp_path,"بازگشت به تکلیف")}</p>',part=n)
    intro = f'''<div class="home-opening"><p class="objective">جعبه را باز کنیم.<br>از اولین حدس تا مدلی که خودمان می‌سازیم.</p><p>برای کسی که Python می‌نویسد و می‌خواهد بفهمد پشت ادامهٔ یک جمله چه اتفاقی می‌افتد. عددها را دنبال می‌کنیم، کد می‌سازیم، گاهی عمداً خرابش می‌کنیم و برای هر نتیجه شاهد می‌آوریم.</p><div class="book-stats"><span><b>{len(LESSONS)}</b>درس</span><span><b>۱۰</b>ایستگاه عملی</span><span><b>۲۳</b>مرحلهٔ ساخت</span><span><b>۱</b>پروژهٔ زنده</span></div></div>'''
    intro += f'<p>{link("index.html","guide.html","از اینجا آغاز کنید: روش کار و نصب")} · {lesson_link("index.html","01-model")} · {link("index.html","project.html","نقشهٔ نسخه‌های پروژه")}</p>'
    intro += '<p><a data-resume hidden>ادامه از آخرین درس</a></p>' + pipeline()
    intro += '<div class="three-spaces"><section><span>۰۱ / بخوان و بساز</span><h2>مسیر مطالعه</h2><p>ریاضی و PyTorch از نخستین نیاز معرفی می‌شوند. پاسخ‌ها جدا هستند تا جا برای فکرکردن بماند.</p></section><section><span>۰۲ / دست‌کاری کن</span><h2>'+link('index.html','lab.html','آزمایشگاه')+'</h2><p>پوشش را بردار، دما را تغییر بده، و اعداد واقعیِ مدل خودت را باز کن.</p></section><section><span>۰۳ / شاهد نگه دار</span><h2>'+link('index.html','journal.html','دفتر آزمایش')+'</h2><p>حدس، تنظیمات، خطا و کشف را ثبت کن؛ محلی، قابل خروجی، بدون حساب.</p></section></div>'
    intro += '<h2 id="route">اطلس مسیر یادگیری</h2><p>دانش قبلی یادگیری عمیق لازم نیست. برای چند هفته کار همراه با تمرین برنامه بریزید؛ معیار عبور، توان توضیح و تغییر کد است.</p><div class="route-grid">' + ''.join(toc) + '</div>'
    page("index.html","از Python تا ساخت Mini-GPT",intro,kind="home")


def render_references():
    glossary = '<p>این واژه‌نامه جای درس را نمی‌گیرد. پیوند هر مدخل شما را به نخستین توضیح در زمینهٔ همان مسئله می‌برد.</p><dl class="glossary">'
    seen = set()
    for lesson in LESSONS:
        for term in re.findall(r'<dfn>(.*?)</dfn>',lesson.body):
            if term in seen:
                continue
            seen.add(term)
            glossary += f'<dt>{term}</dt><dd>{lesson_link("glossary.html",lesson.id)}</dd>'
    page("glossary.html","واژه‌ها در محل یادگیری",glossary+'</dl>')
    from book_src.references import GUIDE, PROJECT, API
    for path, title, body in [("guide.html","چطور با این کتاب کار کنیم؟",GUIDE),
                              ("project.html","پروژه‌ای که همراه شما رشد می‌کند",PROJECT),
                              ("api.html","راهنمای خواندن کد و APIها",API)]:
        page(path,title,resolve(body,path))
    page('lab.html','جعبهٔ مدل را باز کنیم',lab_page(),kind='laboratory')
    page('journal.html','دفتر آزمایش شما',JOURNAL,kind='journal')
    source_files = sorted((ROOT / "mini_gpt").rglob("*.py")) + sorted((ROOT / "mini_gpt").rglob("*.md"))
    source_index = '<p>مرجع نهایی کد؛ ترتیب مطالعه را از درس‌ها بگیرید، نه از این فهرست الفبایی. نام‌های کتابخانه در '+link('code/index.html','api.html','راهنمای کد')+' توضیح داده شده‌اند.</p><ul>'
    for source in source_files:
        source_name = source.relative_to(ROOT).as_posix()
        path = "code/" + source_name + ".html"
        source_index += '<li>'+link('code/index.html',path,source_name)+'</li>'
        related = [l for l in LESSONS if l.source == source_name]
        body = '<p>این فایل مرجع است. متن فارسی درون کد ممکن است به‌علت چیدمان چپ‌به‌راست جدا دیده شود؛ نسخهٔ دانلودی UTF-8 است.</p>'
        body += '<p>'+link(path,'api.html','توضیح نام‌ها و دستورها')+' · '+link(path,'project.html','دریافت همهٔ فایل‌ها')+'</p>'
        if related:
            body += '<p>درس‌های مرتبط: '+ ' · '.join(lesson_link(path,l.id) for l in related)+'</p>'
        body += code_block(source.read_text(encoding='utf-8'))
        page(path,source_name,body)
    page('code/index.html','فایل‌های مرجع پروژه',source_index+'</ul>')


def main(output=None):
    global OUT
    OUT = Path(output).resolve() if output is not None else ROOT / 'dist'
    if len(BY_ID) != len(LESSONS) or len(CHECKPOINTS) != len(PARTS):
        raise ValueError("duplicate lesson IDs or incomplete checkpoints")
    assets = OUT / 'assets'
    assets.mkdir(parents=True,exist_ok=True)
    for name in ('book.css','book.js','experience.js','journal.js'):
        (assets/name).write_text((ROOT/'book_src'/name).read_text(encoding='utf-8'),encoding='utf-8')
    sample = json.loads((ROOT/'data'/'inspection-sample.json').read_text(encoding='utf-8'))
    (assets/'inspection-demo.js').write_text('window.INSPECTION_DEMO = '+json.dumps(sample,ensure_ascii=False,allow_nan=False)+';\n',encoding='utf-8')
    manifest = {'edition':3,'units':[{'id':i,'path':p,'title':t} for i,p,t in UNITS]}
    (assets/'manifest.js').write_text('window.BOOK = '+json.dumps(manifest,ensure_ascii=False)+';\n',encoding='utf-8')
    render_lessons()
    render_structure()
    render_references()
    (OUT/'downloads').mkdir(exist_ok=True)
    packaged = [ROOT/'requirements.txt',ROOT/'README.md']
    for directory in ('mini_gpt','tests','data'):
        packaged.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and p.suffix in ('.py','.md','.txt'))
    with zipfile.ZipFile(OUT/'downloads'/'mini-gpt-project.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(packaged)):
            # Fixed metadata makes a rebuild byte-for-byte reproducible.
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),date_time=(2026,9,19,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info,path.read_bytes())
    print(f"Built {len(LESSONS)} lessons, {len(CHAPTERS)} chapters, {len(PARTS)} parts, {len(UNITS)} progress units.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='Output directory (default: dist).')
    main(parser.parse_args().output)
