"use strict";
(() => {
  const manifest = window.BOOK;
  const allowed = new Set(manifest.units.map(x => x.id));
  const key = "mini-gpt-progress-v3";
  const root = new URL(".", new URL(document.body.dataset.root, location.href));
  let states = Object.create(null), storageOK = true;
  const status = message => { const node = document.querySelector("[data-status]"); if (node) node.textContent = message; };
  const validIDs = ids => Array.isArray(ids) && ids.every(x => typeof x === "string" && allowed.has(x));
  function parseStates(raw) {
    if (!raw) return Object.create(null);
    const data = JSON.parse(raw);
    if (!data || data.version !== 3 || typeof data.states !== "object" || !data.states) throw Error("invalid progress");
    const out = Object.create(null);
    for (const [id, value] of Object.entries(data.states)) {
      if (!allowed.has(id) || !value || typeof value.done !== "boolean" || !Number.isSafeInteger(value.time) || value.time < 0) throw Error("invalid progress");
      out[id] = {done:value.done, time:value.time};
    }
    return out;
  }
  function merge(other) {
    for (const [id, value] of Object.entries(other)) if (!states[id] || value.time > states[id].time) states[id] = value;
  }
  let stored = null;
  try {
    stored = localStorage.getItem(key); states = parseStates(stored);
    if (!stored) {
      const old = JSON.parse(localStorage.getItem("mini-gpt-book-edition-2") || "[]");
      if (validIDs(old)) old.forEach(id => states[id] = {done:true,time:1});
    }
  } catch (_) { storageOK = false; }
  // URL state is a fallback only, never a stale authority over an existing browser record.
  if (!stored) {
    const incoming = new URL(location.href).searchParams.get("done");
    const ids = incoming ? incoming.split(",") : [];
    if (validIDs(ids)) ids.forEach(id => states[id] = {done:true,time:1});
  }
  // File origins may isolate storage per page: transport revisions INCLUDING undone items.
  // Existing HTTP storage remains authoritative over bookmark/query state.
  if(location.protocol === "file:" || !storageOK){
    const carried=new URL(location.href).searchParams.get("progress");
    if(carried&&carried.length<=30000){try{merge(parseStates(carried));}catch(_){status("پیشرفت موجود در پیوند معتبر نبود و نادیده گرفته شد.");}}
  }
  function persist() {
    try { merge(parseStates(localStorage.getItem(key))); localStorage.setItem(key, JSON.stringify({version:3,states})); }
    catch (_) { storageOK = false; }
  }
  function render() {
    const ids = Object.keys(states).filter(id => states[id].done).sort();
    const done = new Set(ids);
    document.querySelectorAll("[data-progress-count]").forEach(x => x.textContent = `${ids.length} / ${allowed.size}`);
    document.querySelectorAll("progress").forEach(x => {x.max=allowed.size;x.value=ids.length;});
    document.querySelectorAll("[data-unit]").forEach(x => x.classList.toggle("completed",done.has(x.dataset.unit)));
    const button = document.querySelector("[data-complete]");
    if (button) { const yes=done.has(button.dataset.complete); button.setAttribute("aria-pressed",String(yes));button.textContent=yes?"✓ انجام شد؛ برای لغو کلیک کنید":"تمرین و خودسنجی را انجام دادم"; }
    const fallback = !storageOK || location.protocol === "file:";
    document.querySelectorAll("a[data-book-link]").forEach(a => {
      const url=new URL(a.getAttribute("href"),location.href);
      url.searchParams.delete("done");
      if(fallback) url.searchParams.set("progress",JSON.stringify({version:3,states})); else url.searchParams.delete("progress");
      a.href=url.href;
    });
    const current=new URL(location.href);
    current.searchParams.delete("done");
    if(fallback) current.searchParams.set("progress",JSON.stringify({version:3,states})); else current.searchParams.delete("progress");
    try { history.replaceState(null,"",current); } catch (_) { /* some file origins reject history changes */ }
    if(!storageOK) status("ذخیرهٔ مرورگر در دسترس نیست. پیشرفت در پیوندها منتقل می‌شود؛ خروجی JSON بگیرید.");
  }
  document.querySelector("[data-complete]")?.addEventListener("click",event=>{
    persist(); const id=event.currentTarget.dataset.complete;
    states[id]={done:!states[id]?.done,time:Math.max(Date.now(),(states[id]?.time||0)+1)};
    persist();render();
  });
  window.addEventListener("storage",event=>{if(event.key===key){try{merge(parseStates(event.newValue));render();}catch(_){status("وضعیت زبانهٔ دیگر معتبر نبود؛ تغییری اعمال نشد.");}}});
  document.querySelectorAll("pre").forEach(pre=>{
    if(pre.closest("[data-export-preview]"))return;
    const wrapper=document.createElement("div");wrapper.className="codebox";pre.parentNode.insertBefore(wrapper,pre);wrapper.append(pre);
    const button=document.createElement("button");button.type="button";button.textContent="کپی کد";wrapper.insertBefore(button,pre);
    button.addEventListener("click",async()=>{
      try{if(!navigator.clipboard||!window.isSecureContext)throw Error("clipboard unavailable");await navigator.clipboard.writeText(pre.textContent);button.textContent="کپی شد";}
      catch(_){const range=document.createRange();range.selectNodeContents(pre);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);button.textContent="انتخاب شد؛ Ctrl+C بزنید";}
    });
  });
  function downloadJSON(value,name){
    const serialized=JSON.stringify(value,null,2);
    try{const url=URL.createObjectURL(new Blob([serialized],{type:"application/json"}));const a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}catch(_){/* visible text is always available */}
    return serialized;
  }
  window.BookUI={downloadJSON,root};
  document.querySelector("[data-export]")?.addEventListener("click",()=>{
    persist();const data={edition:3,completed:Object.keys(states).filter(id=>states[id].done).sort()};
    const preview=document.querySelector("[data-export-preview]");preview.hidden=false;preview.open=true;
    document.querySelector("[data-export-code]").textContent=downloadJSON(data,"learning-progress.json");
    status("خروجی آماده است؛ اگر دانلود انجام نشد، نسخهٔ متنی را کپی کنید.");
  });
  document.querySelector("[data-import]")?.addEventListener("change",async event=>{
    const file=event.target.files[0];if(!file)return;
    try{if(file.size>50000)throw Error("too large");const data=JSON.parse(await file.text());if(![2,3].includes(data.edition)||!validIDs(data.completed))throw Error("invalid");persist();const time=Date.now();data.completed.forEach(id=>states[id]={done:true,time:Math.max(time,(states[id]?.time||0)+1)});persist();render();status("پیشرفت ادغام شد؛ موارد انجام‌شدهٔ فعلی حذف نشدند.");}
    catch(_){status("فایل معتبر نیست؛ خروجی پیشرفت ویرایش دوم یا سوم را وارد کنید. وضعیت فعلی حفظ شد.");}
    event.target.value="";
  });
  const search=document.querySelector("[data-lesson-search]");
  search?.addEventListener("input",()=>{
    const target=document.querySelector("[data-search-results]");target.replaceChildren();const q=search.value.trim().toLocaleLowerCase();if(!q)return;
    const matches=manifest.units.filter(x=>(x.title+" "+x.id).toLocaleLowerCase().includes(q)).slice(0,15);
    for(const item of matches){const a=document.createElement("a");a.textContent=item.title;a.href=new URL(item.path,root);a.dataset.bookLink="";target.append(a);}
    if(!matches.length)target.textContent="در عنوان درس‌ها پیدا نشد؛ واژهٔ کوتاه‌تری امتحان کنید.";
    render();
  });
  try{
    const current=document.body.dataset.unitId;
    if(allowed.has(current))localStorage.setItem("mini-gpt-last-lesson",current);
    const saved=localStorage.getItem("mini-gpt-last-lesson");const item=manifest.units.find(x=>x.id===saved);const resume=document.querySelector("[data-resume]");
    if(item&&resume){resume.href=new URL(item.path,root);resume.textContent="ادامه از آخرین صفحه: "+item.title;resume.dataset.bookLink="";resume.hidden=false;}
  }catch(_){/* resume is optional */}
  persist();render();
})();
